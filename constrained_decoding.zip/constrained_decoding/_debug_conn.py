"""调试连接目标端问题"""
from validate_semantic_rules import extract_aadl_structure, pkg_to_arch_json
from aadl_semantic_full import FullAadlSemanticEngine

filepath = r"c:\Users\heli0\Desktop\osate-examples\examples\stepper-motor\packages\CasePositionControl.aadl"
pkg = extract_aadl_structure(filepath)
arch = pkg_to_arch_json(pkg)

print(f"类型数: {len(arch['type_components'])}")
print(f"实现数: {len(arch['impl_components'])}")

engine = FullAadlSemanticEngine()
engine.prefill_from_arch_json(arch)

# 看看 SMS_App_Process_SMPC.original 的子组件
impl_name = "SMS_App_Process_SMPC.original"
impl = engine.symbols.component_impls.get(impl_name)
print(f"\n{impl_name} 子组件:")
for sname, sub in impl.subcomponents.items():
    print(f"  {sname}: {sub.category} -> {sub.classifier}")
    # 查类型
    t = engine.symbols.component_types.get(sub.classifier)
    print(f"    直接查类型: {t is not None}")
    base = sub.classifier.split(".")[0] if "." in sub.classifier else sub.classifier
    t2 = engine.symbols.component_types.get(base)
    print(f"    查 base 类型 {base}: {t2 is not None}")
    if t2:
        print(f"    端口数: {len(t2.ports)}")
        for pn, pi in t2.ports.items():
            print(f"      {pn}: {pi.direction}")

print(f"\n合法目标端:")
targets = engine.symbols.get_valid_connection_targets(impl_name)
for t in targets:
    print(f"  {t}")

print(f"\n合法源端:")
srcs = engine.symbols.get_valid_connection_sources(impl_name)
for s in srcs:
    print(f"  {s}")
